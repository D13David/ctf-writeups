#!/bin/sh
echo "UWUCTF Launcher v1"
npm start
