you're so lucky I compiled the uwufier for you :)
normally it requires installing rust
