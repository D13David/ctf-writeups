import socket
import binascii
import subprocess

def main():
    host = "0.0.0.0"
    port = 1337

    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))
    server_socket.listen(1)

    print(f"Listening on {host}:{port}...")

    while True:
        client_socket, addr = server_socket.accept()
        print(f"Accepted connection from {addr[0]}:{addr[1]}")
        try:
            data = client_socket.recv(1024)
            hex_string = data.decode('utf-8').strip()
            try:
                decoded_data = binascii.unhexlify(hex_string)
                with open('payload', 'wb') as file:
                    file.write(decoded_data)
                print(f"Hex string saved as payload")
                process = subprocess.run(['./runtime', 'payload'], capture_output=True)
                stdout = process.stdout
                client_socket.send(stdout)
            except binascii.Error:
                print("Invalid hex string received")
                client_socket.send("Invalid hex string received\n".encode('utf-8'))
        except Exception as e:
            print(f"Error: {str(e)}")
        finally:
            client_socket.close()

if __name__ == "__main__":
    main()
