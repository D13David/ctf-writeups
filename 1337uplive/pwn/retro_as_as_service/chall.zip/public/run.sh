#!/usr/bin/sh

docker build --tag=chall .
docker run -p 1337:1337 --rm --name=chall -it chall